package com.sbi.SBI_usingSB.HN.Controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.SBI_usingSB.HN.Model.Customer;
import com.sbi.SBI_usingSB.HN.Server.CustomerService;

@RestController
public class CustomerController 
{
	@Autowired
	CustomerService cs;
	
	@GetMapping("getcustomer")
	public List<Customer> getcustomer() 
	{
		List<Customer> customer=cs.getcustomer();
		return customer;
	}
	
	@PostMapping("insertcustomer")
	public boolean insertcustomer( @RequestBody Customer customer) 
	{
		boolean cst=cs.insertcustomer(customer);
		return cst;
	}
	
	@DeleteMapping("deletecustomer/{id}")
	public String deletecustomer(@PathVariable int id) 
	{
		String customer=cs.deletecustomer(id);
		return customer;
	}
	
	@PutMapping("updatecustomer")
	String updatecustomer(@RequestBody Customer customer) 
	{
		String cst=cs.updatecustomer(customer);
		return cst;
	}

}
