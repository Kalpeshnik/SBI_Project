package com.sbi.SBI_usingSB.HN.Model;

import javax.persistence.Entity;


import javax.persistence.Id;

@Entity
public class Customer 
{
	private int id;
	private String name;
	private String loc;
	
	@Id
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", loc=" + loc + "]";
	}
}
