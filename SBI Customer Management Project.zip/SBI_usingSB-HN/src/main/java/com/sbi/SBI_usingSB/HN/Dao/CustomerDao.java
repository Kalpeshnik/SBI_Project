package com.sbi.SBI_usingSB.HN.Dao;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sbi.SBI_usingSB.HN.Model.Customer;

@Repository
public class CustomerDao 
{
	@Autowired
	SessionFactory sf;
	
	public List<Customer> getcustomer() 
	{
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	List<Customer> customer=criteria.list();
	session.close();
	return customer;
		
	}

	public boolean insertcustomer(Customer customer) {
		Session session=sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(customer);
		tr.commit();
		session.close();
		return true;
	}

	public String deletecustomer(int id) {
		Session session=sf.openSession();
		Transaction tr = session.beginTransaction();
		Customer Customer=session.get(Customer.class, id);
		session.delete(Customer);
		tr.commit();
		session.close();
		return "CUSTOMER DELETED ";
	}

	
	public String updatecustomer(Customer customer) {
		Session session=sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(customer);
		tr.commit();
		session.close();
		return "CUSTOMER UPDATED";
	}
	

}
