package com.sbi.SBI_usingSB.HN.Server;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.SBI_usingSB.HN.Dao.CustomerDao;
import com.sbi.SBI_usingSB.HN.Model.Customer;

@Service
public class CustomerService 
{
	@Autowired
	CustomerDao cd;

	public List<Customer> getcustomer() 
	{
		List<Customer> customer=cd.getcustomer();
		return customer;
	}

	public boolean insertcustomer(Customer customer) {
		return cd.insertcustomer(customer);
	}

	public String deletecustomer(int id) {
		return cd.deletecustomer(id);
	}

	public String updatecustomer(Customer customer) {
		return cd.updatecustomer(customer);
	}

}
